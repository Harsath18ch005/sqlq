<nav class="navbar-side" role="navigation">
            <div class="navbar-collapse sidebar-collapse collapse">
                <ul id="side" class="nav navbar-nav side-nav">
                    <!-- begin SIDE NAV USER PANEL -->
                    
                    <!-- end SIDE NAV USER PANEL -->
                    <!-- begin SIDE NAV SEARCH -->
                    
                    <!-- end SIDE NAV SEARCH -->
                    <!-- begin DASHBOARD LINK -->
                    <li>
                        <a class="active" href="index.php">
                            <i class="fa fa-dashboard"></i> Dashboard        <?php  $fff=$_SESSION['type']; //echo"$fff";?>
                        </a>
                    </li>
                    <!-- end DASHBOARD LINK -->
                
                
                
                
                    <!-- begin CHARTS DROPDOWN -->
                 <?php  $fff=$_SESSION['type'];?>
               <?php  if($fff=='admin'){
			 
			   ?>
                  <li>
                                <a href="new_project.php">
                                    <i class="fa fa-angle-double-right"></i>New Project
                                </a>
                            </li>
                
                             <?php }?> 
                   
                    <!-- end PAGES DROPDOWN -->
                </ul>
                <!-- /.side-nav -->
            </div>
            <!-- /.navbar-collapse -->
        </nav>