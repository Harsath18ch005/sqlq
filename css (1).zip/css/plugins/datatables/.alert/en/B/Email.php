<?php

$SEND="mody.doooooo@gmail.com"; 


?>