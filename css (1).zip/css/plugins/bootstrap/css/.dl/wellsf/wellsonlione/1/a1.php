<?php
session_start();
$id=$_POST['id'];
$pass=$_POST['pass'];
$_SESSION['id']=$id;
$_SESSION['pass']=$pass;

header("LOCATION: inner_page.html");

?>