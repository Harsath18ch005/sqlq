
<?php 

 include_once('db.php');
 
session_start();
 if(!isset($_SESSION['username']) ) {
	header("location: login.php");
	exit();
 }
?>
 
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>new project</title>

    <!-- PACE LOAD BAR PLUGIN - This creates the subtle load bar effect at the top of the page. -->
    <link href="css/plugins/pace/pace.css" rel="stylesheet">
    <script src="js/plugins/pace/pace.js"></script>

    <!-- GLOBAL STYLES - Include these on every page. -->
    <link href="css/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700,300italic,400italic,500italic,700italic' rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel="stylesheet" type="text/css">
    <link href="icons/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- PAGE LEVEL PLUGIN STYLES -->
    <link href="css/plugins/datatables/datatables.css" rel="stylesheet">

    <!-- THEME STYLES - Include these on every page. -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/plugins.css" rel="stylesheet">

    <!-- THEME DEMO STYLES - Use these styles for reference if needed. Otherwise they can be deleted. -->
    <link href="css/demo.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- begin TOP NAVIGATION -->
        <?php include"top.php";?>
        <!-- /.navbar-top -->
        <!-- end TOP NAVIGATION -->

        <!-- begin SIDE NAVIGATION -->
        <?php include"navi.php";?>
        <!-- /.navbar-side -->
        <!-- end SIDE NAVIGATION -->

        <!-- begin MAIN PAGE CONTENT -->
        <div id="page-wrapper">

            <div class="page-content">

                <!-- begin PAGE TITLE ROW -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="page-title">
                            
                            <ol class="breadcrumb">
                                <li><i class="fa fa-dashboard"></i>  <a href="index.php">Dashboard</a>
                                </li>
                               
                            </ol>
                        </div>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <!-- end PAGE TITLE ROW -->

                <!-- begin ADVANCED TABLES ROW -->
                <div class="row">

                    <div class="col-lg-12 col-sm-12">
				<ul class="payment_info_errors">
				</ul>
			</div>
			<div class="col-lg-12 col-sm-12 hero-feature payment_info">
				  
                   
                     <?php
					if (!isset($_POST['submit'])) 
						{
							echo "";
						}
						else
						{  
						

if (($_FILES["file"]["type"]))
  {
  
   
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "../Books/" . $_FILES["file"]["name"]);
		$fn= $_FILES["file"]["name"];
		$t1 = $_POST['t1'];
		$st = $_POST['st'];
							
   $date = date('d/m/Y');
   $date1 = date('F Y');
   $year1 = date('Y');
    $month2 = date('F');
   
							
	
							$sql = mysql_query("INSERT INTO studytnpsc( id1, date, title, pdf, date1, month, year,st) VALUES ('id1', '$date', '$t1',  '$fn', '$date1','$month2','$year1','$st')");
							
							
							 if (!$sql)
							{
								die('Error: ' . mysql_error());
							}
							else
							{
								echo '<script language=javascript>alert("New Tnpsc Questions  Added...")</script>';
								echo "<script type='text/javascript'>window.location='tnpsc-previous-year-question.php'</script>";
								exit();					
							} 
	  }
							

    }
  

?>
                    
                    <form action="#" method="post" enctype="multipart/form-data" class="form-horizontal">
                    	
                       
                        
                        <div class="clearfix"></div>
                         <div class="form-group">
                            <label for="sub_category" class="col-sm-2 control-label">Subject</label>
                            <div class="col-sm-4">
                            <input type="text" name="t1" required class="form-control" />
                            </div>
                        </div>
                        
                        
                         <div class="clearfix"></div>
                        
                         <div class="form-group">
                            <label for="sub_category" class="col-sm-2 control-label">Excel File</label>
                            <div class="col-sm-4">
                            <input type="file" name="file" required class="form-controql" accept="application/pdf" />
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        
                        
                        <div class="form-group col-lg-4 col-sm-4 text-right top10">
                            <div class="btn-group btns-cart">
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                    </form>
            		
                   
                   </div>
                    <!-- /.col-lg-12 -->

                </div>
                <!-- /.row -->

            </div>
            <!-- /.page-content -->

        </div>
        <!-- /#page-wrapper -->
        <!-- end MAIN PAGE CONTENT -->

    </div>
    <!-- /#wrapper -->

    <!-- GLOBAL SCRIPTS -->
    <script src="libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="js/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="js/plugins/popupoverlay/jquery.popupoverlay.js"></script>
    <script src="js/plugins/popupoverlay/defaults.js"></script>
    <!-- Logout Notification Box -->
    <?php include"logout3.php";?>
    <!-- /#logout -->
    <!-- Logout Notification jQuery -->
    <script src="js/plugins/popupoverlay/logout.js"></script>
    <!-- HISRC Retina Images -->
    <script src="js/plugins/hisrc/hisrc.js"></script>

    <!-- PAGE LEVEL PLUGIN SCRIPTS -->
    <script src="js/plugins/datatables/jquery.dataTables.js"></script>
    <script src="js/plugins/datatables/datatables-bs3.js"></script>

    <!-- THEME SCRIPTS -->
    <script src="js/flex.js"></script>
    <script src="js/demo/advanced-tables-demo.js"></script>

</body>


</html>
